# What is in this bundle, and what is deliberately not

Everything here is **irreplaceable or expensive to regenerate**. The 45 GB pixel cache and the 1.2 GB
Inductor cache are excluded — see the bottom.

## Must not be regenerated

- `folds.csv` — **frozen**. Regenerating it invalidates every CV number recorded against it, because
  the greedy assignment is deterministic only for a fixed input. Treat as read-only.
- `llm_labels.jsonl` / `llm_labels_gold.jsonl` — one overnight qwen3:14b pass over 4,406 reports. Not
  bit-reproducible even at temperature 0, so this is an artifact to keep, not to rebuild.
- `train_targets.parquet` / `train_weights.parquet` — what training actually reads. Rebuildable by
  `scripts/build_targets.py` *only* if the LLM labels above survive.

## Cheap to regenerate, included because they are tiny

`lang.csv`, `rule_*.parquet`, `llm_{targets,weights,evidence}.parquet`, `adjudication_queue.csv`,
`meta/*.parquet` (a header-only Kaggle kernel), and the per-shard cache manifests.

The cache manifests matter more than their size suggests: they carry the per-study slot-presence mask
that `KneeStudies` feeds to the masked slot attention.

## The experiment record

`runs/*.log`, `*_history.csv`, `*_per_class.csv`, `*_log.jsonl`, `oof_predictions.parquet`. This is the
CV↔LB audit trail; `docs/experiments.md` in git references these runs by tag.

Checkpoints (`*.pt`, ~113 MB each) are in `checkpoints/` if you asked for them.

## Excluded on purpose

- `artifacts/kaggle_cache/*.npy` — 45 GB, and it came from Kaggle in the first place. Re-fetch with
  `kaggle kernels output antonsadeq/rsna-knee-cache-336`, or rerun the 4 shards.
- `artifacts/inductor_cache` — 1.2 GB of kernels autotuned for **sm_120 (RTX 5090)**. Useless on a
  4090 (sm_89) and best deleted rather than copied; it rebuilds itself on first compiled run.
